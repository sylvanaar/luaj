print( '\a\n >>> testC not active: skipping API tests <<<\n\a' )
print( '\a\b\f\n\r\v\\\'\"\[\]' )