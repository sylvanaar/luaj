while i ~= f do
    i,v = next(self, i)
end
