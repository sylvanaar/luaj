  while i ~= f do
--    if not i then return end
    i,v = next(self, i)
  end
